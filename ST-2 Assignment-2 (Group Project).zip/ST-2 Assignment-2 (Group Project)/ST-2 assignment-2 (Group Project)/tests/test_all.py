import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import unittest
import time
from modules.stack    import Stack
from modules.queue_ds import Queue


# MODULE 1 — Data Structures Tests
class TestStack(unittest.TestCase):
    def test_push_pop_lifo(self):
        """Push 3 items, pop 2 — final size=1, correct LIFO order"""
        s=Stack()
        s.push(1); s.push(2); s.push(3)
        self.assertEqual(s.pop(), 3)
        self.assertEqual(s.pop(), 2)
        self.assertEqual(s.size(), 1)

    def test_peek(self):
        s=Stack(); s.push(42)
        self.assertEqual(s.peek(), 42)
        self.assertEqual(s.size(), 1)  # peek doesn't remove

    def test_empty_exceptions(self):
        s=Stack()
        with self.assertRaises(IndexError): s.pop()
        with self.assertRaises(IndexError): s.peek()

    def test_benchmark(self):
        s=Stack(); n=10**6
        start=time.time()
        for i in range(n): s.push(i)
        for i in range(n): s.pop()
        print(f"\nStack benchmark {n} push/pop: {time.time()-start:.4f}s")


class TestQueue(unittest.TestCase):
    def test_enqueue_dequeue_fifo(self):
        """Enqueue 4 items, dequeue 3 — FIFO order maintained"""
        q=Queue()
        for v in [10,20,30,40]: q.enqueue(v)
        self.assertEqual(q.dequeue(), 10)
        self.assertEqual(q.dequeue(), 20)
        self.assertEqual(q.dequeue(), 30)
        self.assertEqual(q.size(), 1)

    def test_peek_front(self):
        q=Queue(); q.enqueue(5); q.enqueue(99)
        self.assertEqual(q.peek(), 5)   # front, not back

    def test_empty_exceptions(self):
        q=Queue()
        with self.assertRaises(IndexError): q.dequeue()
        with self.assertRaises(IndexError): q.peek()

    def test_fifo_order(self):
        q=Queue()
        q.enqueue("first"); q.enqueue("second"); q.enqueue("third")
        self.assertEqual(q.dequeue(), "first")
        self.assertEqual(q.dequeue(), "second")
        self.assertEqual(q.dequeue(), "third")


class TestLinkedList(unittest.TestCase):
    """Tests for the linked list logic (pure Python, no pygame)"""
    class Node:
        def __init__(self,v): self.value=v; self.next=None
    class LL:
        def __init__(self): self.head=None
        def append(self,v):
            n=TestLinkedList.Node(v)
            if not self.head: self.head=n; return
            c=self.head
            while c.next: c=c.next
            c.next=n
        def insert_at(self,pos,v):
            n=TestLinkedList.Node(v)
            if pos==0 or not self.head: n.next=self.head; self.head=n; return
            c=self.head
            for _ in range(pos-1):
                if not c.next: break
                c=c.next
            n.next=c.next; c.next=n
        def to_list(self):
            r=[]; c=self.head
            while c: r.append(c.value); c=c.next
            return r
        def reverse(self):
            prev=None; cur=self.head
            while cur: nxt=cur.next; cur.next=prev; prev=cur; cur=nxt
            self.head=prev

    def test_insert_at_position(self):
        """Insert node with value 10 at position 2 — node present in correct location"""
        ll=self.LL()
        ll.append(1); ll.append(2); ll.append(3)
        ll.insert_at(2, 10)
        self.assertEqual(ll.to_list(), [1,2,10,3])

    def test_insert_at_front(self):
        ll=self.LL(); ll.append(5); ll.append(10)
        ll.insert_at(0, 99)
        self.assertEqual(ll.to_list()[0], 99)

    def test_reverse(self):
        ll=self.LL()
        for v in [1,2,3,4]: ll.append(v)
        ll.reverse()
        self.assertEqual(ll.to_list(), [4,3,2,1])


class TestBST(unittest.TestCase):
    """Tests for BST insert and inorder traversal"""
    class BSTNode:
        def __init__(self,v): self.value=v; self.left=self.right=None
    class BST:
        def __init__(self): self.root=None
        def insert(self,v):
            def _i(n,v):
                if not n: return TestBST.BSTNode(v)
                if v<n.value: n.left=_i(n.left,v)
                elif v>n.value: n.right=_i(n.right,v)
                return n
            self.root=_i(self.root,v)
        def inorder(self):
            r=[]
            def _in(n):
                if n: _in(n.left); r.append(n.value); _in(n.right)
            _in(self.root); return r

    def test_bst_inorder(self):
        """Insert [50,30,70]; inorder traversal = [30,50,70]"""
        bst=self.BST()
        bst.insert(50); bst.insert(30); bst.insert(70)
        self.assertEqual(bst.inorder(), [30,50,70])

    def test_bst_no_duplicates(self):
        bst=self.BST()
        bst.insert(10); bst.insert(10)
        self.assertEqual(bst.inorder(), [10])



# MODULE 2 — Sorting Tests
class TestSorting(unittest.TestCase):
    def _bubble(self, a):
        a=a[:]; n=len(a)
        for i in range(n):
            for j in range(n-i-1):
                if a[j]>a[j+1]: a[j],a[j+1]=a[j+1],a[j]
        return a

    def _selection(self, a):
        a=a[:]; n=len(a)
        for i in range(n):
            mi=i
            for j in range(i+1,n):
                if a[j]<a[mi]: mi=j
            a[i],a[mi]=a[mi],a[i]
        return a

    def _merge(self, a):
        if len(a)<=1: return a
        m=len(a)//2
        L=self._merge(a[:m]); R=self._merge(a[m:])
        res=[]; i=j=0
        while i<len(L) and j<len(R):
            if L[i]<=R[j]: res.append(L[i]); i+=1
            else: res.append(R[j]); j+=1
        return res+L[i:]+R[j:]

    def test_bubble_sort(self):
        """Sort [5,3,8,1,2] → [1,2,3,5,8]"""
        self.assertEqual(self._bubble([5,3,8,1,2]), [1,2,3,5,8])

    def test_selection_sort(self):
        self.assertEqual(self._selection([5,3,8,1,2]), [1,2,3,5,8])

    def test_merge_sort(self):
        self.assertEqual(self._merge([5,3,8,1,2]), [1,2,3,5,8])

    def test_already_sorted(self):
        a=[1,2,3,4,5]
        self.assertEqual(self._bubble(a), a)
        self.assertEqual(self._selection(a), a)
        self.assertEqual(self._merge(a), a)



# MODULE 3 — Graph Traversal Tests
import collections as _col

class TestGraph(unittest.TestCase):
    graph={'A':['B','C'],'B':['A','D','E'],'C':['A','F'],'D':['B'],'E':['B','F'],'F':['C','E']}

    def _bfs(self, start):
        visited=set(); q=_col.deque([start]); order=[]
        while q:
            c=q.popleft()
            if c in visited: continue
            visited.add(c); order.append(c)
            for nb in self.graph[c]:
                if nb not in visited: q.append(nb)
        return order

    def _dfs(self, start):
        visited=set(); stack=[start]; order=[]
        while stack:
            c=stack.pop()
            if c in visited: continue
            visited.add(c); order.append(c)
            for nb in reversed(self.graph[c]):
                if nb not in visited: stack.append(nb)
        return order

    def test_bfs_from_A(self):
        """BFS from A visits all nodes reachable in correct BFS order"""
        order=self._bfs('A')
        self.assertEqual(order[0], 'A')        # A must be first
        self.assertIn('B', order); self.assertIn('C', order)
        self.assertEqual(len(order), 6)         # all 6 nodes visited

    def test_dfs_from_C(self):
        """DFS from C visits all reachable nodes"""
        order=self._dfs('C')
        self.assertEqual(order[0], 'C')
        self.assertEqual(len(order), 6)

    def test_interactive_start_node(self):
        """BFS restarts correctly from any chosen node"""
        for start in ['A','B','C','D','E','F']:
            order=self._bfs(start)
            self.assertEqual(order[0], start)


if __name__ == "__main__":
    unittest.main(verbosity=2)
