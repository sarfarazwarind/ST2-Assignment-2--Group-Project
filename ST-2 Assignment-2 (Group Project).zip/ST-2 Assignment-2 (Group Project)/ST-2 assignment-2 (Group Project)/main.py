import pygame
import sys

pygame.init()


WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer and Visualiser App")

FONT = pygame.font.SysFont(None, 36)
clock = pygame.time.Clock()


from modules import phase1_data_structures as _p1
from modules import phase2_algorithms       as _p2
from modules import phase3_puzzles          as _p3


def draw_text(text, pos):
    txt = FONT.render(text, True, (0, 0, 0))
    screen.blit(txt, pos)


def main_menu():
    screen.fill((200, 200, 250))
    draw_text("Algorithm Explorer", (WIDTH // 3, 50))

    buttons = {
        'Data Structures': pygame.Rect(300, 150, 200, 50),
        'Sorting':         pygame.Rect(300, 230, 200, 50),
        'Graphs':          pygame.Rect(300, 310, 200, 50),
        'Heap':            pygame.Rect(300, 390, 200, 50),
        'Puzzles':         pygame.Rect(300, 470, 200, 50)
    }

    for text, rect in buttons.items():
        pygame.draw.rect(screen, (150, 150, 200), rect)
        draw_text(text, (rect.x + 20, rect.y + 10))

    pygame.display.flip()
    return buttons




def data_structures_module():
    """Phase 1 — Stack, Queue, Linked List, BST"""
    _p1.run(screen, WIDTH, HEIGHT)


def sorting_module():
    """Phase 2 — Bubble, Selection, Merge Sort"""
    _p2.run_sorting(screen, WIDTH, HEIGHT)


def graphs_module():
    """Phase 2 — BFS and DFS Graph Traversal"""
    _p2.run_graph(screen, WIDTH, HEIGHT)


def heap_module():
    """Phase 2 — Min-Heap Insertion and Extraction"""
    _p2.run_heap(screen, WIDTH, HEIGHT)


def puzzles_module():
    """Phase 3 — A* Pathfinding, Event Queue, DP Grid"""
    _p3.run(screen, WIDTH, HEIGHT)


def main():
    running = True
    current_module = None
    buttons = main_menu()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and current_module is None:
                pos = event.pos
                for name, rect in buttons.items():
                    if rect.collidepoint(pos):
                        current_module = name

        if current_module is None:
            buttons = main_menu()
        else:
            if current_module == 'Data Structures':
                data_structures_module()
            elif current_module == 'Sorting':
                sorting_module()
            elif current_module == 'Graphs':
                graphs_module()
            elif current_module == 'Heap':
                heap_module()
            elif current_module == 'Puzzles':
                puzzles_module()


            current_module = None

        clock.tick(30)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
