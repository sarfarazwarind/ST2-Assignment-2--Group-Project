"""
Phase 2 - Algorithm Visualizer
Contains: Bubble/Selection/Merge Sort, BFS/DFS Graph, Heap Visualizer
"""
import pygame
import sys
import random
import math
import collections

C_BG       = (245, 245, 250)
C_BLOCK    = (100, 150, 250)
C_GOLD     = (255, 210,  60)
C_RED      = (220,  80,  80)
C_GREEN    = ( 80, 200, 100)
C_PURPLE   = (160,  80, 220)
C_DARK     = ( 50,  50,  50)
C_WHITE    = (255, 255, 255)
C_TEXT     = (  0,   0,   0)
C_SUBTITLE = ( 80,  80, 180)

def _font(s=26): return pygame.font.SysFont(None, s)
def _btn(screen, rect, label, col, hover=False):
    c=tuple(min(v+40,255) for v in col) if hover else col
    pygame.draw.rect(screen,c,rect,border_radius=8)
    pygame.draw.rect(screen,C_WHITE,rect,2,border_radius=8)
    t=_font(22).render(label,True,C_WHITE)
    screen.blit(t,t.get_rect(center=rect.center))



# 1. SORTING VISUALIZER
def run_sorting(screen, W, H):
    clock=pygame.time.Clock()
    N=36; bw=W//N; BTN_H=80; SH=H-BTN_H
    arr=[random.randint(20,SH-40) for _ in range(N)]
    active=""

    def draw(arr, compare=[], swap=[], sorted_i=set(), merge_i=[]):
        screen.fill(C_BG)
        title=_font(30).render("Sorting Visualizer — "+active if active else "Sorting Visualizer",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,18)))
        for i,v in enumerate(arr):
            col=C_BLOCK
            if i in compare: col=C_RED
            if i in swap:    col=C_GREEN
            if i in sorted_i: col=C_PURPLE
            if i in merge_i:  col=C_GOLD
            pygame.draw.rect(screen,col,(i*bw,SH-v,bw-1,v))
        pygame.draw.rect(screen,(220,220,230),(0,SH,W,BTN_H))
        mx,my=pygame.mouse.get_pos()
        buttons={"Bubble":pygame.Rect(10,SH+15,130,45),"Selection":pygame.Rect(155,SH+15,130,45),
                 "Merge":pygame.Rect(300,SH+15,130,45),"Reset":pygame.Rect(W-150,SH+15,130,45)}
        cols={"Bubble":(60,130,200),"Selection":(60,180,80),"Merge":(200,120,40),"Reset":(160,60,60)}
        for lbl,rect in buttons.items():
            _btn(screen,rect,lbl,cols[lbl],rect.collidepoint(mx,my))
        pygame.display.flip()
        return buttons

    def bubble(a):
        n=len(a); si=set()
        for i in range(n):
            for j in range(n-i-1):
                draw(a,compare=[j,j+1],sorted_i=si); pygame.time.wait(25)
                for e in pygame.event.get():
                    if e.type==pygame.QUIT: pygame.quit(); sys.exit()
                if a[j]>a[j+1]: a[j],a[j+1]=a[j+1],a[j]; draw(a,swap=[j,j+1],sorted_i=si); pygame.time.wait(25)
            si.add(n-1-i)
        draw(a,sorted_i=set(range(n)))

    def selection(a):
        n=len(a); si=set()
        for i in range(n):
            mi=i
            for j in range(i+1,n):
                draw(a,compare=[j],swap=[mi],sorted_i=si); pygame.time.wait(25)
                for e in pygame.event.get():
                    if e.type==pygame.QUIT: pygame.quit(); sys.exit()
                if a[j]<a[mi]: mi=j
            a[i],a[mi]=a[mi],a[i]; si.add(i)
            draw(a,swap=[i,mi],sorted_i=si); pygame.time.wait(40)
        draw(a,sorted_i=set(range(n)))

    def merge(a):
        def ms(arr,left):
            if len(arr)<=1: return arr
            mid=len(arr)//2
            L=ms(arr[:mid],left); R=ms(arr[mid:],left+mid)
            merged=[]; i=j=0
            while i<len(L) and j<len(R):
                for e in pygame.event.get():
                    if e.type==pygame.QUIT: pygame.quit(); sys.exit()
                draw(a,merge_i=list(range(left,left+len(arr)))); pygame.time.wait(30)
                if L[i]<=R[j]: merged.append(L[i]); i+=1
                else: merged.append(R[j]); j+=1
            merged+=L[i:]; merged+=R[j:]
            for k,v in enumerate(merged): a[left+k]=v
            draw(a,merge_i=list(range(left,left+len(arr)))); pygame.time.wait(30)
            return merged
        ms(a,0); draw(a,sorted_i=set(range(len(a))))

    running=True
    while running:
        buttons=draw(arr)
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN and e.key==pygame.K_ESCAPE: running=False
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                if buttons["Bubble"].collidepoint(e.pos):    active="Bubble Sort";    bubble(arr[:])
                elif buttons["Selection"].collidepoint(e.pos): active="Selection Sort"; selection(arr[:])
                elif buttons["Merge"].collidepoint(e.pos):   active="Merge Sort";      merge(arr[:])
                elif buttons["Reset"].collidepoint(e.pos):
                    arr=[random.randint(20,SH-40) for _ in range(N)]; active=""
        clock.tick(60)



# 2. GRAPH TRAVERSAL (BFS + DFS)
def run_graph(screen, W, H):
    clock=pygame.time.Clock()
    nodes_pos={'A':(120,120),'B':(300,70),'C':(300,220),'D':(480,120),'E':(580,180),'F':(480,320)}
    graph={'A':['B','C'],'B':['A','D','E'],'C':['A','F'],'D':['B'],'E':['B','F'],'F':['C','E']}
    NR=26; mode="BFS"; start=None; status="B=BFS  D=DFS  Click a node to start  ESC=Back"

    def draw(visited=set(),frontier=set(),current=None,order=[]):
        screen.fill(C_BG)
        title=_font(30).render(f"Graph Traversal — {mode}",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,22)))
        for n,nbrs in graph.items():
            x1,y1=nodes_pos[n]
            for nb in nbrs:
                x2,y2=nodes_pos[nb]
                pygame.draw.line(screen,(160,160,160),(x1,y1),(x2,y2),2)
        for n,(x,y) in nodes_pos.items():
            col=(200,200,200)
            if n in visited: col=C_GREEN
            if n in frontier: col=C_GOLD
            if n==current: col=C_RED
            pygame.draw.circle(screen,col,(x,y),NR)
            if n==start: pygame.draw.circle(screen,(0,0,200),(x,y),NR+4,3)
            pygame.draw.circle(screen,C_DARK,(x,y),NR,2)
            t=_font(24).render(n,True,C_TEXT); screen.blit(t,t.get_rect(center=(x,y)))
        if order:
            ot=_font(20).render("Order: "+" -> ".join(order),True,(0,120,0)); screen.blit(ot,(10,H-56))
        legend=[(C_GREEN,"Visited"),(C_GOLD,"Frontier"),(C_RED,"Current")]
        for i,(c,l) in enumerate(legend):
            pygame.draw.circle(screen,c,(W-120,60+i*26),9)
            screen.blit(_font(20).render(l,True,C_DARK),(W-106,53+i*26))
        st=_font(20).render(status,True,C_DARK); screen.blit(st,(10,H-28))
        pygame.display.flip()

    def bfs(s):
        visited=set(); q=collections.deque([s]); order=[]
        while q:
            c=q.popleft()
            if c in visited: continue
            visited.add(c); order.append(c)
            draw(visited,set(q),c,order); pygame.time.wait(650)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            for nb in graph[c]:
                if nb not in visited and nb not in q: q.append(nb)
        draw(visited,order=order)

    def dfs(s):
        visited=set(); stack=[s]; order=[]
        while stack:
            c=stack.pop()
            if c in visited: continue
            visited.add(c); order.append(c)
            draw(visited,set(stack),c,order); pygame.time.wait(650)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            for nb in reversed(graph[c]):
                if nb not in visited: stack.append(nb)
        draw(visited,order=order)

    def clicked_node(pos):
        for n,(x,y) in nodes_pos.items():
            if (pos[0]-x)**2+(pos[1]-y)**2<=NR**2: return n
        return None

    running=True
    while running:
        draw(visited=set(), frontier=set(), current=None, order=[])
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_b: mode="BFS"; status="BFS mode — click a node to start"
                elif e.key==pygame.K_d: mode="DFS"; status="DFS mode — click a node to start"
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                n=clicked_node(e.pos)
                if n:
                    start=n
                    if mode=="BFS": bfs(n)
                    else: dfs(n)
        clock.tick(30)



# 3. HEAP VISUALIZER
def run_heap(screen, W, H):
    clock=pygame.time.Clock(); heap=[]; status="SPACE=Insert random  E=Extract min  C=Clear  ESC=Back"

    def draw(hl=[]):
        screen.fill(C_BG)
        title=_font(30).render("Min-Heap Visualizer",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,22)))
        if not heap:
            t=_font(26).render("Heap is empty — press SPACE to insert",True,C_DARK)
            screen.blit(t,t.get_rect(center=(W//2,H//2)))
        else:
            npos=[]
            for i in range(len(heap)):
                lv=int(math.floor(math.log2(i+1)))
                il=i-(2**lv-1); gap=W//(2**lv+1)
                x=gap*(il+1); y=70+lv*75; npos.append((x,y))
            for i in range(len(heap)):
                for ch in [2*i+1,2*i+2]:
                    if ch<len(heap): pygame.draw.line(screen,C_DARK,npos[i],npos[ch],2)
            for i,(x,y) in enumerate(npos):
                col=C_RED if i in hl else C_BLOCK
                pygame.draw.circle(screen,col,(x,y),22)
                pygame.draw.circle(screen,C_WHITE,(x,y),22,2)
                t=_font(22).render(str(heap[i]),True,C_WHITE); screen.blit(t,t.get_rect(center=(x,y)))
        # Array view at bottom
        ar=_font(20).render("Array: "+str(heap),True,C_DARK); screen.blit(ar,(10,H-52))
        st=_font(20).render(status,True,C_DARK); screen.blit(st,(10,H-26))
        pygame.display.flip()

    def heapify_up(idx):
        while idx>0:
            p=(idx-1)//2
            if heap[p]>heap[idx]:
                heap[p],heap[idx]=heap[idx],heap[p]; draw([p,idx]); pygame.time.wait(400); idx=p
            else: break

    def heapify_down(idx):
        n=len(heap)
        while True:
            l,r,sm=2*idx+1,2*idx+2,idx
            if l<n and heap[l]<heap[sm]: sm=l
            if r<n and heap[r]<heap[sm]: sm=r
            if sm!=idx: heap[idx],heap[sm]=heap[sm],heap[idx]; draw([idx,sm]); pygame.time.wait(400); idx=sm
            else: break

    def insert(v):
        heap.append(v); draw([len(heap)-1]); pygame.time.wait(300); heapify_up(len(heap)-1)

    def extract():
        if not heap: return
        heap[0]=heap[-1]; heap.pop(); draw([0]); pygame.time.wait(300)
        if heap: heapify_down(0)

    running=True
    while running:
        draw()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_SPACE: insert(random.randint(1,99)); status=f"Inserted {heap[-1] if heap else '?'}"
                elif e.key==pygame.K_e:
                    if heap: status=f"Extracted min: {heap[0]}"; extract()
                    else: status="Heap is empty!"
                elif e.key==pygame.K_c: heap.clear(); status="Heap cleared"
        clock.tick(30)



# Phase 2 Sub-menu
def run(screen, W, H):

    clock  = pygame.time.Clock()
    items  = ["Sorting Algorithms","Graph Traversal (BFS/DFS)","Heap Visualizer","Back"]
    sel    = 0
    C_MENU_BG  = (200, 200, 250)
    C_BTN      = (150, 150, 200)
    C_BTN_SEL  = (100, 100, 220)
    C_BTN_HOV  = (120, 120, 180)
    FONT36     = pygame.font.SysFont(None, 36)
    FONT26     = pygame.font.SysFont(None, 26)

    while True:
        screen.fill(C_MENU_BG)
        t = FONT36.render("Phase 2 — Algorithm Visualizer", True, (40,40,120))
        screen.blit(t, t.get_rect(center=(W//2, 60)))
        t2 = FONT26.render("Sorting · Graph BFS/DFS · Heap", True, (80,80,160))
        screen.blit(t2, t2.get_rect(center=(W//2, 100)))

        mx, my = pygame.mouse.get_pos()
        rects = []
        for i, item in enumerate(items):
            rect = pygame.Rect(W//2-150, 140+i*80, 300, 52)
            rects.append(rect)
            hover = rect.collidepoint(mx, my)
            col = C_BTN_SEL if i==sel else (C_BTN_HOV if hover else C_BTN)
            pygame.draw.rect(screen, col, rect)
            if i==sel: pygame.draw.rect(screen, (255,255,255), rect, 2)
            lbl = FONT26.render(item, True, (255,255,255) if i==sel else (0,0,0))
            screen.blit(lbl, lbl.get_rect(center=rect.center))

        hint = FONT26.render("UP/DOWN + ENTER or Click   ESC = back", True, (80,80,120))
        screen.blit(hint, hint.get_rect(center=(W//2, H-25)))
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_DOWN: sel=(sel+1)%len(items)
                elif e.key==pygame.K_UP: sel=(sel-1)%len(items)
                elif e.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                    ch=items[sel]
                    if ch=="Sorting Algorithms": run_sorting(screen,W,H)
                    elif ch=="Graph Traversal (BFS/DFS)": run_graph(screen,W,H)
                    elif ch=="Heap Visualizer": run_heap(screen,W,H)
                    elif ch=="Back": return
                elif e.key==pygame.K_ESCAPE: return
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                for i,rect in enumerate(rects):
                    if rect.collidepoint(e.pos):
                        sel=i
                        ch=items[i]
                        if ch=="Sorting Algorithms": run_sorting(screen,W,H)
                        elif ch=="Graph Traversal (BFS/DFS)": run_graph(screen,W,H)
                        elif ch=="Heap Visualizer": run_heap(screen,W,H)
                        elif ch=="Back": return
        clock.tick(30)
