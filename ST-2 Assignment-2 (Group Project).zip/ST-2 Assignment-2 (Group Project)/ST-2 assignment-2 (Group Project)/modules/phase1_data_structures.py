"""
Phase 1 - Data Structures Module
Contains: Stack, Queue, Linked List, BST visualizations
All run() functions accept (screen, WIDTH, HEIGHT) and return when done.
"""
import pygame
import sys
import math
from modules.stack    import Stack
from modules.queue_ds import Queue


# Shared colours used across all visualizers
C_BG       = (245, 245, 250)
C_BLOCK    = (100, 150, 250)
C_GOLD     = (255, 210, 60)
C_RED      = (220,  80,  80)
C_GREEN    = ( 80, 200, 100)
C_DARK     = ( 50,  50,  50)
C_WHITE    = (255, 255, 255)
C_TEXT     = (  0,   0,   0)
C_SUBTITLE = ( 80,  80, 180)


def _font(size=26): return pygame.font.SysFont(None, size)
def _btn(screen, rect, label, col, hover=False):
    c = tuple(min(v+40,255) for v in col) if hover else col
    pygame.draw.rect(screen, c, rect, border_radius=8)
    pygame.draw.rect(screen, C_WHITE, rect, 2, border_radius=8)
    t = _font(24).render(label, True, C_WHITE)
    screen.blit(t, t.get_rect(center=rect.center))



# 1. STACK VISUALIZER
def run_stack(screen, W, H):
    clock  = pygame.time.Clock()
    stack  = Stack()
    ctr    = 1
    status = "SPACE = Push  |  BACKSPACE = Pop  |  ESC = Back"
    BW, BH = 180, 44
    SX     = (W - BW) // 2
    BASE_Y = H - BH - 70
    BLOCK_H = 42

    running = True
    while running:
        mx, my = pygame.mouse.get_pos()
        screen.fill(C_BG)
        title = _font(34).render("Stack Visualizer", True, C_SUBTITLE)
        screen.blit(title, title.get_rect(center=(W//2, 28)))

        # Draw stack blocks bottom-up
        for i, val in enumerate(stack._data):
            y    = BASE_Y - i * (BLOCK_H + 4)
            rect = pygame.Rect(SX, y, BW, BLOCK_H)
            pygame.draw.rect(screen, C_BLOCK, rect, border_radius=6)
            pygame.draw.rect(screen, C_WHITE, rect, 2, border_radius=6)
            t = _font(26).render(str(val), True, C_TEXT)
            screen.blit(t, t.get_rect(center=rect.center))

        # label
        if not stack.is_empty():
            top_y = BASE_Y - (stack.size()-1) * (BLOCK_H+4)
            tl = _font(20).render("← TOP", True, C_RED)
            screen.blit(tl, (SX + BW + 8, top_y + 12))

        # Buttons
        BTN_PUSH = pygame.Rect(W//2 - 210, H-60, 120, 40)
        BTN_POP  = pygame.Rect(W//2 -  60, H-60, 120, 40)
        BTN_BACK = pygame.Rect(W//2 +  90, H-60, 120, 40)
        _btn(screen, BTN_PUSH, "Push",  (60,130,200), BTN_PUSH.collidepoint(mx,my))
        _btn(screen, BTN_POP,  "Pop",   (180,60,60),  BTN_POP.collidepoint(mx,my))
        _btn(screen, BTN_BACK, "Back",  (100,100,100),BTN_BACK.collidepoint(mx,my))

        st = _font(20).render(status, True, C_DARK)
        screen.blit(st, (10, H-90))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    stack.push(ctr); ctr += 1; status = f"Pushed {ctr-1}"
                elif event.key == pygame.K_BACKSPACE:
                    if not stack.is_empty(): v=stack.pop(); status=f"Popped {v}"
                    else: status = "Stack is empty!"
                elif event.key == pygame.K_ESCAPE:
                    running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if BTN_PUSH.collidepoint(event.pos):
                    stack.push(ctr); ctr += 1; status = f"Pushed {ctr-1}"
                elif BTN_POP.collidepoint(event.pos):
                    if not stack.is_empty(): v=stack.pop(); status=f"Popped {v}"
                    else: status = "Stack is empty!"
                elif BTN_BACK.collidepoint(event.pos):
                    running = False
        clock.tick(30)



# 2. QUEUE VISUALIZER
def run_queue(screen, W, H):
    clock  = pygame.time.Clock()
    queue  = Queue()
    ctr    = 1
    anim_blocks = []
    ANIM_SPEED  = 14
    BW, BH = 80, 46
    GAP    = 8
    QY     = H // 2 - BH // 2
    status = "Click Enqueue / Dequeue  |  ESC = Back"

    BTN_ENQ  = pygame.Rect(W//2-180, H-60, 140, 40)
    BTN_DEQ  = pygame.Rect(W//2- 20, H-60, 140, 40)
    BTN_BACK = pygame.Rect(W//2+140, H-60, 100, 40)

    def bx(i): return 30 + i*(BW+GAP)

    def do_enq():
        nonlocal ctr
        queue.enqueue(ctr)
        anim_blocks.append({"val":ctr,"x":float(W+10),"target":float(bx(queue.size()-1)),"done":False,"dir":"in"})
        ctr += 1

    def do_deq():
        if queue.is_empty(): return
        val = queue.dequeue()
        anim_blocks.append({"val":val,"x":float(bx(0)),"target":float(-BW-20),"done":False,"dir":"out"})

    running = True
    while running:
        mx, my = pygame.mouse.get_pos()
        screen.fill(C_BG)
        title = _font(34).render("Queue Visualizer", True, C_SUBTITLE)
        screen.blit(title, title.get_rect(center=(W//2,28)))
        lbl = _font(22).render(f"Queue size: {queue.size()}   FRONT ->", True, C_DARK)
        screen.blit(lbl, (30, QY-38))

        # Settled blocks
        for i, val in enumerate(queue._data):
            rect = pygame.Rect(bx(i), QY, BW, BH)
            pygame.draw.rect(screen, C_BLOCK, rect, border_radius=6)
            pygame.draw.rect(screen, C_WHITE, rect, 2, border_radius=6)
            t = _font(24).render(str(val), True, C_TEXT)
            screen.blit(t, t.get_rect(center=rect.center))

        # Animation
        for ab in anim_blocks:
            rect = pygame.Rect(int(ab["x"]), QY, BW, BH)
            pygame.draw.rect(screen, C_GOLD, rect, border_radius=6)
            t = _font(24).render(str(ab["val"]), True, C_TEXT)
            screen.blit(t, t.get_rect(center=rect.center))
            dx = ab["target"] - ab["x"]
            ab["x"] += ANIM_SPEED if dx > 0 else -ANIM_SPEED
            if abs(dx) <= ANIM_SPEED: ab["x"] = ab["target"]; ab["done"] = True
        anim_blocks[:] = [a for a in anim_blocks if not a["done"]]

        _btn(screen, BTN_ENQ,  "Enqueue", (60,160,60),  BTN_ENQ.collidepoint(mx,my))
        _btn(screen, BTN_DEQ,  "Dequeue", (180,60,60),  BTN_DEQ.collidepoint(mx,my))
        _btn(screen, BTN_BACK, "Back",    (100,100,100),BTN_BACK.collidepoint(mx,my))
        st = _font(20).render(status, True, C_DARK)
        screen.blit(st, (10, H-92))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if BTN_ENQ.collidepoint(event.pos):  do_enq(); status=f"Enqueued {ctr-1}"
                elif BTN_DEQ.collidepoint(event.pos): do_deq(); status="Dequeued front"
                elif BTN_BACK.collidepoint(event.pos): running = False
        clock.tick(60)



# 3. LINKED LIST VISUALIZER
class _Node:
    def __init__(self, v): self.value=v; self.next=None

class _LinkedList:
    def __init__(self): self.head=None
    def append(self, v):
        n=_Node(v)
        if not self.head: self.head=n; return
        c=self.head
        while c.next: c=c.next
        c.next=n
    def delete_last(self):
        if not self.head: return
        if not self.head.next: self.head=None; return
        c=self.head
        while c.next.next: c=c.next
        c.next=None
    def insert_at(self, pos, v):
        n=_Node(v)
        if pos==0 or not self.head: n.next=self.head; self.head=n; return
        c=self.head
        for _ in range(pos-1):
            if not c.next: break
            c=c.next
        n.next=c.next; c.next=n
    def reverse(self):
        prev=None; cur=self.head
        while cur: nxt=cur.next; cur.next=prev; prev=cur; cur=nxt
        self.head=prev
    def to_list(self):
        r=[]; c=self.head
        while c: r.append(c.value); c=c.next
        return r

def _get_input(screen, W, H, prompt):
    font=_font(28); sf=_font(22); inp=""
    while True:
        screen.fill(C_BG)
        pt=font.render(prompt+inp+"_", True, C_SUBTITLE)
        screen.blit(pt, (40, H//2-20))
        ht=sf.render("ENTER confirm  |  ESC cancel", True, C_DARK)
        screen.blit(ht, (40, H//2+20))
        pygame.display.flip()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_RETURN:
                    try: return int(inp)
                    except: inp=""
                elif e.key==pygame.K_ESCAPE: return None
                elif e.key==pygame.K_BACKSPACE: inp=inp[:-1]
                elif e.unicode.lstrip('-').isdigit() or (e.unicode=='-' and inp==""): inp+=e.unicode

def run_linked_list(screen, W, H):
    clock=pygame.time.Clock(); ll=_LinkedList(); status="A=Append  D=Delete Last  I=Insert  R=Reverse  ESC=Back"
    NR=24; GAP=140
    for v in [5,10,15]: ll.append(v)

    def draw():
        screen.fill(C_BG)
        title=_font(34).render("Linked List Visualizer", True, C_SUBTITLE)
        screen.blit(title, title.get_rect(center=(W//2,28)))
        nodes=ll.to_list(); y=H//2
        for i,val in enumerate(nodes):
            x=60+i*GAP
            pygame.draw.circle(screen, C_BLOCK, (x,y), NR)
            pygame.draw.circle(screen, C_WHITE, (x,y), NR, 2)
            t=_font(24).render(str(val), True, C_WHITE)
            screen.blit(t, t.get_rect(center=(x,y)))
            if i<len(nodes)-1:
                pygame.draw.line(screen, C_DARK, (x+NR,y),(x+GAP-NR,y),2)
                pygame.draw.polygon(screen, C_DARK, [(x+GAP-NR,y-5),(x+GAP-NR+8,y),(x+GAP-NR,y+5)])
        st=_font(20).render(status, True, C_DARK)
        screen.blit(st, (10, H-30))
        ctrl=_font(20).render("A=Append  D=Delete  I=Insert  R=Reverse  ESC=Back", True, (120,120,120))
        screen.blit(ctrl, (10, H-55))
        pygame.display.flip()

    running=True
    while running:
        draw()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_a:
                    v=_get_input(screen,W,H,"Append value: ")
                    if v is not None: ll.append(v); status=f"Appended {v}"
                elif e.key==pygame.K_d:
                    ll.delete_last(); status="Deleted last node"
                elif e.key==pygame.K_i:
                    pos=_get_input(screen,W,H,"Insert at pos (0=front): ")
                    if pos is not None:
                        v=_get_input(screen,W,H,f"Value for pos {pos}: ")
                        if v is not None: ll.insert_at(pos,v); status=f"Inserted {v} at pos {pos}"
                elif e.key==pygame.K_r:
                    ll.reverse(); status="List reversed!"
        clock.tick(30)



# 4.BST VISUALIZER
class _BSTNode:
    def __init__(self,v): self.value=v; self.left=self.right=None

class _BST:
    def __init__(self): self.root=None
    def insert(self,v):
        def _i(n,v):
            if not n: return _BSTNode(v)
            if v<n.value: n.left=_i(n.left,v)
            elif v>n.value: n.right=_i(n.right,v)
            return n
        self.root=_i(self.root,v)
    def inorder(self):
        r=[]
        def _in(n):
            if n: _in(n.left); r.append(n); _in(n.right)
        _in(self.root); return r
    def preorder(self):
        r=[]
        def _pre(n):
            if n: r.append(n); _pre(n.left); _pre(n.right)
        _pre(self.root); return r
    def postorder(self):
        r=[]
        def _post(n):
            if n: _post(n.left); _post(n.right); r.append(n)
        _post(self.root); return r
    def search(self,v):
        path=[]; c=self.root
        while c:
            path.append(c)
            if v==c.value: return path
            c=c.left if v<c.value else c.right
        return path
    def delete(self,v):
        def _d(n,v):
            if not n: return n
            if v<n.value: n.left=_d(n.left,v)
            elif v>n.value: n.right=_d(n.right,v)
            else:
                if not n.left and not n.right: return None
                if not n.left: return n.right
                if not n.right: return n.left
                s=n.right
                while s.left: s=s.left
                n.value=s.value; n.right=_d(n.right,s.value)
            return n
        self.root=_d(self.root,v)

def run_bst(screen, W, H):
    clock=pygame.time.Clock(); bst=_BST(); status="I=Insert  D=Delete  1=Inorder  2=Preorder  3=Postorder  S=Search  ESC=Back"
    NR=22
    for v in [50,30,70,20,40,60,80]: bst.insert(v)

    def draw_tree(node, x, y, xoff, hl=None, sp=None, npos={}):
        if node:
            npos[node]=(x,y)
            col=(255,120,120) if hl and node in hl else (255,210,60) if sp and node in sp else C_BLOCK
            if node.left:
                cx=x-xoff; cy=y+75
                pygame.draw.line(screen,(120,120,120),(x,y+NR),(cx,cy-NR),2)
                draw_tree(node.left,cx,cy,max(xoff//2,28),hl,sp,npos)
            if node.right:
                cx=x+xoff; cy=y+75
                pygame.draw.line(screen,(120,120,120),(x,y+NR),(cx,cy-NR),2)
                draw_tree(node.right,cx,cy,max(xoff//2,28),hl,sp,npos)
            pygame.draw.circle(screen,col,(x,y),NR)
            pygame.draw.circle(screen,C_WHITE,(x,y),NR,2)
            t=_font(22).render(str(node.value),True,C_TEXT)
            screen.blit(t,t.get_rect(center=(x,y)))

    def animate_trav(nodes, label):
        for nd in nodes:
            screen.fill(C_BG)
            title=_font(34).render("BST - "+label, True, C_SUBTITLE)
            screen.blit(title,title.get_rect(center=(W//2,28)))
            draw_tree(bst.root, W//2, 70, 160, hl={nd})
            order=" -> ".join(str(n.value) for n in nodes[:nodes.index(nd)+1])
            ot=_font(20).render(order,True,(0,120,0))
            screen.blit(ot,(10,H-30))
            pygame.display.flip(); pygame.time.wait(600)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()

    def animate_search(val):
        path=bst.search(val); visited=set()
        for nd in path:
            visited.add(nd)
            screen.fill(C_BG)
            title=_font(34).render("BST - Search", True, C_SUBTITLE)
            screen.blit(title,title.get_rect(center=(W//2,28)))
            draw_tree(bst.root,W//2,70,160,sp=visited)
            found=nd.value==val
            msg=f"Found {val}!" if found else f"Go {'left' if val<nd.value else 'right'}"
            mt=_font(22).render(msg,True,C_RED); screen.blit(mt,(10,H-30))
            pygame.display.flip(); pygame.time.wait(600)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            if found: pygame.time.wait(500); return

    running=True
    while running:
        screen.fill(C_BG)
        title=_font(34).render("BST Visualizer", True, C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,28)))
        draw_tree(bst.root,W//2,70,160,npos={})
        st=_font(19).render(status,True,C_DARK); screen.blit(st,(10,H-30))
        ctrl=_font(19).render("I=Insert  D=Delete  1/2/3=Traversal  S=Search  ESC=Back",True,(120,120,120))
        screen.blit(ctrl,(10,H-52))
        pygame.display.flip()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_i:
                    v=_get_input(screen,W,H,"Insert value: ")
                    if v is not None: bst.insert(v); status=f"Inserted {v}"
                elif e.key==pygame.K_d:
                    v=_get_input(screen,W,H,"Delete value: ")
                    if v is not None: bst.delete(v); status=f"Deleted {v}"
                elif e.key==pygame.K_1: animate_trav(bst.inorder(),"In-order"); status="In-order done"
                elif e.key==pygame.K_2: animate_trav(bst.preorder(),"Pre-order"); status="Pre-order done"
                elif e.key==pygame.K_3: animate_trav(bst.postorder(),"Post-order"); status="Post-order done"
                elif e.key==pygame.K_s:
                    v=_get_input(screen,W,H,"Search value: ")
                    if v is not None: animate_search(v); status=f"Search {v} done"
        pygame.time.Clock().tick(30)



# Phase 1 Sub-menu
def run(screen, W, H):

    clock  = pygame.time.Clock()
    items  = ["Stack","Queue","Linked List","BST","Back"]
    sel    = 0
    C_MENU_BG  = (200, 200, 250)
    C_BTN      = (150, 150, 200)
    C_BTN_SEL  = (100, 100, 220)
    C_BTN_HOV  = (120, 120, 180)
    FONT36     = pygame.font.SysFont(None, 36)
    FONT26     = pygame.font.SysFont(None, 26)

    while True:
        screen.fill(C_MENU_BG)
        t = FONT36.render("Phase 1 — Data Structures", True, (40,40,120))
        screen.blit(t, t.get_rect(center=(W//2, 60)))
        t2 = FONT26.render("Stack · Queue · Linked List · BST", True, (80,80,160))
        screen.blit(t2, t2.get_rect(center=(W//2, 100)))

        mx, my = pygame.mouse.get_pos()
        rects = []
        for i, item in enumerate(items):
            rect = pygame.Rect(W//2-100, 140+i*70, 200, 50)
            rects.append(rect)
            hover = rect.collidepoint(mx, my)
            col = C_BTN_SEL if i==sel else (C_BTN_HOV if hover else C_BTN)
            pygame.draw.rect(screen, col, rect)
            if i==sel: pygame.draw.rect(screen, (255,255,255), rect, 2)
            lbl = FONT26.render(item, True, (255,255,255) if i==sel else (0,0,0))
            screen.blit(lbl, lbl.get_rect(center=rect.center))

        hint = FONT26.render("UP/DOWN + ENTER or Click   ESC = back", True, (80,80,120))
        screen.blit(hint, hint.get_rect(center=(W//2, H-25)))
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_DOWN: sel=(sel+1)%len(items)
                elif e.key==pygame.K_UP: sel=(sel-1)%len(items)
                elif e.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                    ch=items[sel]
                    if ch=="Stack": run_stack(screen,W,H)
                    elif ch=="Queue": run_queue(screen,W,H)
                    elif ch=="Linked List": run_linked_list(screen,W,H)
                    elif ch=="BST": run_bst(screen,W,H)
                    elif ch=="Back": return
                elif e.key==pygame.K_ESCAPE: return
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                for i,rect in enumerate(rects):
                    if rect.collidepoint(e.pos):
                        sel=i
                        ch=items[i]
                        if ch=="Stack": run_stack(screen,W,H)
                        elif ch=="Queue": run_queue(screen,W,H)
                        elif ch=="Linked List": run_linked_list(screen,W,H)
                        elif ch=="BST": run_bst(screen,W,H)
                        elif ch=="Back": return
        clock.tick(30)
