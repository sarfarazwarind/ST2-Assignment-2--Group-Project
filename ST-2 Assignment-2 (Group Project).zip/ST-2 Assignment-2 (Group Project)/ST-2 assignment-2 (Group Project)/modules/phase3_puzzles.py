"""
Phase 3 - Puzzle Challenges
Contains: A* Pathfinding, Priority Queue Event Simulator, DP Grid Puzzle
"""
import pygame
import sys
import math
import heapq

C_BG       = (245, 245, 250)
C_DARK     = ( 50,  50,  50)
C_WHITE    = (255, 255, 255)
C_TEXT     = (  0,   0,   0)
C_SUBTITLE = ( 80,  80, 180)
C_RED      = (220,  80,  80)
C_GREEN    = ( 80, 200, 100)
C_GOLD     = (255, 210,  60)
C_BLOCK    = (100, 150, 250)

def _font(s=24): return pygame.font.SysFont(None, s)
def _btn(screen, rect, label, col, hover=False):
    c=tuple(min(v+40,255) for v in col) if hover else col
    pygame.draw.rect(screen,c,rect,border_radius=8)
    pygame.draw.rect(screen,C_WHITE,rect,2,border_radius=8)
    t=_font(22).render(label,True,C_WHITE)
    screen.blit(t,t.get_rect(center=rect.center))


# 1. A* PATHFINDING PUZZLE
def run_pathfinding(screen, W, H):
    clock=pygame.time.Clock()
    ROWS=18; COLS=24; CS=min(W//COLS,(H-100)//ROWS)
    OX=(W-COLS*CS)//2; OY=50

    grid=[[0]*COLS for _ in range(ROWS)]
    start=(0,0); end=(ROWS-1,COLS-1); mode="wall"; path=[]; visited_cells=set()
    status="Click=Wall  S=Set Start  E=Set End  SPACE=Run A*  R=Reset  ESC=Back"

    def cell(mx,my):
        c=(mx-OX)//CS; r=(my-OY)//CS
        return (r,c) if 0<=r<ROWS and 0<=c<COLS else None

    def heuristic(a,b): return abs(a[0]-b[0])+abs(a[1]-b[1])

    def astar():
        nonlocal path,visited_cells
        path=[]; visited_cells=set()
        open_set=[]; heapq.heappush(open_set,(0,start))
        came_from={}; g={start:0}
        f={start:heuristic(start,end)}
        while open_set:
            _,cur=heapq.heappop(open_set)
            visited_cells.add(cur)
            draw()
            pygame.time.wait(18)
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            if cur==end:
                p=[]
                while cur in came_from: p.append(cur); cur=came_from[cur]
                p.append(start); path=p[::-1]; return
            for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                nr,nc=cur[0]+dr,cur[1]+dc
                nb=(nr,nc)
                if 0<=nr<ROWS and 0<=nc<COLS and grid[nr][nc]==0:
                    tg=g[cur]+1
                    if nb not in g or tg<g[nb]:
                        came_from[nb]=cur; g[nb]=tg; f[nb]=tg+heuristic(nb,end)
                        heapq.heappush(open_set,(f[nb],nb))

    def draw():
        screen.fill(C_BG)
        title=_font(28).render("A* Pathfinding Puzzle",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,22)))
        for r in range(ROWS):
            for c in range(COLS):
                rect=pygame.Rect(OX+c*CS,OY+r*CS,CS-1,CS-1)
                col=(220,220,220)
                if grid[r][c]==1:          col=(60,60,60)
                if (r,c) in visited_cells: col=(200,230,255)
                if (r,c) in path:          col=C_GOLD
                if (r,c)==start:           col=C_GREEN
                if (r,c)==end:             col=C_RED
                pygame.draw.rect(screen,col,rect)
        st=_font(19).render(status,True,C_DARK); screen.blit(st,(10,H-46))
        legend=[(C_GREEN,"Start"),(C_RED,"End"),((60,60,60),"Wall"),(C_GOLD,"Path"),((200,230,255),"Visited")]
        for i,(c,l) in enumerate(legend):
            pygame.draw.rect(screen,c,(10+i*120,H-22,14,14))
            screen.blit(_font(18).render(l,True,C_DARK),(28+i*120,H-24))
        pygame.display.flip()

    running=True
    while running:
        draw()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_SPACE: astar(); status="A* complete! Path shown in gold."
                elif e.key==pygame.K_r:
                    grid=[[0]*COLS for _ in range(ROWS)]; path=[]; visited_cells=set(); status="Reset!"
                elif e.key==pygame.K_s: mode="start"; status="Click a cell to set START"
                elif e.key==pygame.K_e: mode="end";   status="Click a cell to set END"
                elif e.key==pygame.K_w: mode="wall";  status="Click cells to place/remove walls"
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                cell_pos=cell(*e.pos)
                if cell_pos:
                    r,c=cell_pos
                    if mode=="wall": grid[r][c]=1-grid[r][c]; path=[]; visited_cells=set()
                    elif mode=="start": start=(r,c); mode="wall"; status="Start set! Click=Wall SPACE=Run"
                    elif mode=="end":   end=(r,c);   mode="wall"; status="End set! Click=Wall SPACE=Run"
        clock.tick(60)



# 2. PRIORITY QUEUE EVENT SIMULATOR
def run_event_queue(screen, W, H):
    clock=pygame.time.Clock()
    heap=[]
    processed=None
    status="SPACE=Process next  A=Add event  C=Clear  ESC=Back"

    initial=[
        (1,"System Backup"),(3,"Deploy Update"),(2,"Restart Server"),
        (5,"Send Report"),(7,"Run Tests"),(4,"Code Review"),
        (8,"Team Meeting"),(6,"Archive Logs"),
    ]
    for ev in initial:
        heap.append(ev)
        heap.sort()

    def draw():
        screen.fill(C_BG)
        title=_font(30).render("Priority Queue Event Simulator",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,22)))

        # heap tree (Left side)
        pw=W//2-10
        pygame.draw.line(screen,(200,200,200),(pw,50),(pw,H-60),2)
        _font(22).render("Heap Tree",True,C_SUBTITLE)
        if heap:
            npos=[]
            for i in range(len(heap)):
                lv=int(math.floor(math.log2(i+1)))
                il=i-(2**lv-1); gap=pw//(2**lv+1)
                x=gap*(il+1); y=70+lv*70; npos.append((x,y))
            for i in range(len(heap)):
                for ch in [2*i+1,2*i+2]:
                    if ch<len(heap): pygame.draw.line(screen,C_DARK,npos[i],npos[ch],2)
            for i,(x,y) in enumerate(npos):
                col=C_RED if i==0 else C_BLOCK
                pygame.draw.circle(screen,col,(x,y),22)
                pygame.draw.circle(screen,C_WHITE,(x,y),22,2)
                t=_font(20).render(str(heap[i][0]),True,C_WHITE); screen.blit(t,t.get_rect(center=(x,y)))

        # event list (Right side)
        rx=pw+20
        ht=_font(24).render("Upcoming Events",True,C_SUBTITLE); screen.blit(ht,(rx,50))
        for i,(pri,desc) in enumerate(sorted(heap)[:10]):
            col=C_RED if i==0 else C_DARK
            row=_font(21).render(f"t={pri:>3}  {desc}",True,col)
            screen.blit(row,(rx,80+i*26))

        # Processed event bar
        if processed:
            pygame.draw.rect(screen,(200,255,210),(0,H-80,W,50))
            pt=_font(24).render(f"Processed: t={processed[0]}  '{processed[1]}'",True,(0,120,0))
            screen.blit(pt,(10,H-68))

        st=_font(19).render(status,True,C_DARK); screen.blit(st,(10,H-26))
        pygame.display.flip()

    def get_input(prompt, allow_text=False):
        inp=""
        while True:
            screen.fill(C_BG)
            t=_font(26).render(prompt+inp+"_",True,C_SUBTITLE); screen.blit(t,(40,H//2-20))
            h=_font(20).render("ENTER confirm  ESC cancel",True,C_DARK); screen.blit(h,(40,H//2+20))
            pygame.display.flip()
            for e in pygame.event.get():
                if e.type==pygame.QUIT: pygame.quit(); sys.exit()
                elif e.type==pygame.KEYDOWN:
                    if e.key==pygame.K_RETURN:
                        if allow_text: return inp if inp else None
                        try: return int(inp)
                        except: inp=""
                    elif e.key==pygame.K_ESCAPE: return None
                    elif e.key==pygame.K_BACKSPACE: inp=inp[:-1]
                    else:
                        if allow_text: inp+=e.unicode
                        elif e.unicode.isdigit(): inp+=e.unicode

    def extract():
        nonlocal processed,heap
        if not heap: return
        heap.sort()
        processed=heap.pop(0)

    running=True
    while running:
        draw()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_SPACE: extract(); status="Processed! SPACE=Next"
                elif e.key==pygame.K_a:
                    pri=get_input("Priority (number): ")
                    if pri is not None:
                        desc=get_input("Description: ",allow_text=True)
                        if desc: heap.append((pri,desc)); heap.sort(); status=f"Added event t={pri}"
                elif e.key==pygame.K_c: heap.clear(); processed=None; status="Cleared"
        clock.tick(30)


# 3. DP GRID PUZZLE
def run_dp_grid(screen, W, H):
    clock=pygame.time.Clock()


    DW, DH = 800, 720
    pygame.display.set_mode((DW, DH))
    W, H = DW, DH

    ROWS=6; COLS=6; CS=95
    OX=(W-COLS*CS)//2; OY=110
    dp=[[None]*COLS for _ in range(ROWS)]
    obstacles=set(); path=set()
    status="Click=Toggle obstacle  SPACE=Count paths  P=Show path  R=Reset  ESC=Back"

    def cell(mx,my):
        c=(mx-OX)//CS; r=(my-OY)//CS
        return (r,c) if 0<=r<ROWS and 0<=c<COLS else None

    def count():
        nonlocal dp,path
        dp=[[None]*COLS for _ in range(ROWS)]; path=set()
        for r in range(ROWS):
            for c in range(COLS):
                if (r,c) in obstacles: dp[r][c]=0; continue
                if r==0 and c==0: dp[r][c]=1
                else:
                    up=dp[r-1][c] if r>0 else 0
                    left=dp[r][c-1] if c>0 else 0
                    dp[r][c]=(up or 0)+(left or 0)
                draw((r,c)); pygame.time.wait(200)
                for e in pygame.event.get():
                    if e.type==pygame.QUIT: pygame.quit(); sys.exit()

    def reconstruct():
        nonlocal path
        path=set(); r,c=ROWS-1,COLS-1
        if not dp[r][c]: return
        path.add((r,c))
        while r>0 or c>0:
            up=dp[r-1][c] if r>0 else -1
            left=dp[r][c-1] if c>0 else -1
            if up is None: up=-1
            if left is None: left=-1
            if up>=left and r>0: r-=1
            else: c-=1
            path.add((r,c))

    def draw(hl=None):
        screen.fill(C_BG)
        title=_font(28).render("DP Grid Path Puzzle",True,C_SUBTITLE)
        screen.blit(title,title.get_rect(center=(W//2,22)))
        # Legend (2x2 grid)
        legend=[((60,60,60),"Obstacle"),(C_RED,"Filling"),(C_BLOCK,"Filled"),(C_GREEN,"Path")]
        for i,(col,lbl) in enumerate(legend):
            ci=i%2; ri=i//2; lx=10+ci*220; ly=50+ri*22
            pygame.draw.rect(screen,col,(lx,ly,14,14))
            screen.blit(_font(19).render(lbl,True,C_DARK),(lx+18,ly))
        for r in range(ROWS):
            for c in range(COLS):
                rect=pygame.Rect(OX+c*CS,OY+r*CS,CS-1,CS-1)
                if (r,c) in obstacles: col=(60,60,60)
                elif (r,c) in path:    col=C_GREEN
                elif hl==(r,c):        col=C_RED
                elif dp[r][c] is not None: col=C_BLOCK
                else:                  col=(210,210,210)
                pygame.draw.rect(screen,col,rect)
                pygame.draw.rect(screen,C_DARK,rect,1)
                v=dp[r][c]
                if v is not None and (r,c) not in obstacles:
                    t=_font(26).render(str(v),True,C_WHITE); screen.blit(t,t.get_rect(center=rect.center))
                elif (r,c) in obstacles:
                    t=_font(26).render("X",True,C_WHITE); screen.blit(t,t.get_rect(center=rect.center))
        st=_font(19).render(status,True,C_DARK); screen.blit(st,(10,H-26))
        pygame.display.flip()

    running=True
    while running:
        draw()
        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE:
                    running=False
                    pygame.display.set_mode((800, 600))   # restore original size
                elif e.key==pygame.K_SPACE: count(); status="Done! P=Show path"
                elif e.key==pygame.K_p:
                    if dp[0][0] is not None: reconstruct(); status="Path shown in green!"
                elif e.key==pygame.K_r:
                    obstacles=set(); dp=[[None]*COLS for _ in range(ROWS)]; path=set(); status="Reset!"
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                cp=cell(*e.pos)
                if cp and cp not in [(0,0),(ROWS-1,COLS-1)]:
                    if cp in obstacles: obstacles.remove(cp)
                    else: obstacles.add(cp)
                    dp=[[None]*COLS for _ in range(ROWS)]; path=set()
        clock.tick(30)
    pygame.display.set_mode((800, 600))


# Phase 3 Sub-menu
def run(screen, W, H):

    clock  = pygame.time.Clock()
    items  = ["A* Pathfinding Puzzle","Event Queue Simulator","DP Grid Puzzle","Back"]
    sel    = 0
    C_MENU_BG  = (200, 200, 250)
    C_BTN      = (150, 150, 200)
    C_BTN_SEL  = (100, 100, 220)
    C_BTN_HOV  = (120, 120, 180)
    FONT36     = pygame.font.SysFont(None, 36)
    FONT26     = pygame.font.SysFont(None, 26)

    while True:
        screen.fill(C_MENU_BG)
        t = FONT36.render("Phase 3 — Puzzle Challenges", True, (40,40,120))
        screen.blit(t, t.get_rect(center=(W//2, 60)))
        t2 = FONT26.render("A* Pathfinding · Event Queue · DP Grid", True, (80,80,160))
        screen.blit(t2, t2.get_rect(center=(W//2, 100)))

        mx, my = pygame.mouse.get_pos()
        rects = []
        for i, item in enumerate(items):
            rect = pygame.Rect(W//2-170, 140+i*80, 340, 52)
            rects.append(rect)
            hover = rect.collidepoint(mx, my)
            col = C_BTN_SEL if i==sel else (C_BTN_HOV if hover else C_BTN)
            pygame.draw.rect(screen, col, rect)
            if i==sel: pygame.draw.rect(screen, (255,255,255), rect, 2)
            lbl = FONT26.render(item, True, (255,255,255) if i==sel else (0,0,0))
            screen.blit(lbl, lbl.get_rect(center=rect.center))

        hint = FONT26.render("UP/DOWN + ENTER or Click   ESC = back", True, (80,80,120))
        screen.blit(hint, hint.get_rect(center=(W//2, H-25)))
        pygame.display.flip()

        for e in pygame.event.get():
            if e.type==pygame.QUIT: pygame.quit(); sys.exit()
            elif e.type==pygame.KEYDOWN:
                if e.key==pygame.K_DOWN: sel=(sel+1)%len(items)
                elif e.key==pygame.K_UP: sel=(sel-1)%len(items)
                elif e.key in (pygame.K_RETURN,pygame.K_KP_ENTER):
                    ch=items[sel]
                    if ch=="A* Pathfinding Puzzle": run_pathfinding(screen,W,H)
                    elif ch=="Event Queue Simulator": run_event_queue(screen,W,H)
                    elif ch=="DP Grid Puzzle": run_dp_grid(screen,W,H)
                    elif ch=="Back": return
                elif e.key==pygame.K_ESCAPE: return
            elif e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                for i,rect in enumerate(rects):
                    if rect.collidepoint(e.pos):
                        sel=i
                        ch=items[i]
                        if ch=="A* Pathfinding Puzzle": run_pathfinding(screen,W,H)
                        elif ch=="Event Queue Simulator": run_event_queue(screen,W,H)
                        elif ch=="DP Grid Puzzle": run_dp_grid(screen,W,H)
                        elif ch=="Back": return
        clock.tick(30)
