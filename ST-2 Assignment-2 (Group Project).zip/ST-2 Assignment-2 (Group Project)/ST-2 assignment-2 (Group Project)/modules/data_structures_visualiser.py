"""
data_structures_visualiser.py
Replaces the original Week 10 Task 1.3 file.
Now fully implemented — Stack, Queue, Linked List, BST all working.
Called by main.py via: data_structures_visualiser.run(screen)
"""
from modules.phase1_data_structures import run
